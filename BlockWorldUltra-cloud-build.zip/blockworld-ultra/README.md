# Block World Ultra

Block World Ultra is the portable Android app project for the TEENU.ME Block World game.

It is made for your situation: you do not need to install Android Studio, Node.js, JDK, Gradle, Capacitor, or Android SDK on this computer. The APK is built in the cloud.

## What This Makes

- A real Android APK project
- App name: `Block World Ultra`
- App ID: `com.teenu.blockworldultra`
- The app opens from the Android home screen
- No Chrome tab, no browser address bar
- The game runs inside Android WebView, which is how HTML/JS games become APK apps
- Current mode: singleplayer

## Files

- `index.html` - APK/web app entry file
- `src/main.js` - Block World game code
- `src/styles.css` - mobile/desktop game styling
- `capacitor.config.json` - Capacitor Android app config
- `package.json` - cloud build dependencies and scripts
- `.github/workflows/blockworld-ultra-apk.yml` - GitHub cloud APK build

## Cloud APK Build

Use GitHub Actions so this PC stays clean.

1. Put this repo on GitHub.
2. Open the repo on GitHub.
3. Go to `Actions`.
4. Choose `Build Block World Ultra APK`.
5. Click `Run workflow`.
6. Wait for the build to finish.
7. Download the artifact named `BlockWorldUltra.apk`.

The final APK file will come from the cloud build. Do not create a fake APK file.

## Optional Local Commands

These are only for a computer that is allowed to install developer tools:

```bash
cd blockworld-ultra
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

Debug APK output:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

Rename it to:

```text
BlockWorldUltra.apk
```

## Upload To TEENU.ME

After the cloud build gives you the APK, upload it to:

```text
downloads/BlockWorldUltra.apk
```

Then a download button can point to:

```text
https://teenu.me/downloads/BlockWorldUltra.apk
```

## Test Checklist

- Install APK on Android
- Launch from app icon
- Confirm no browser address bar appears
- Start a world
- Test joystick movement
- Test swipe camera look
- Test jump, break, place
- Test hotbar and `...` block picker
- Test empty hotbar slot
- Test doors, beds, seats, ladders, clock, calendar
- Test sleeping to start a new day
- Close and reopen app to confirm local saves survive
