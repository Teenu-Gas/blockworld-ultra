import * as THREE from "three";

const TYPES = {
  floor: { emoji: "⬛", color: 0x6b7280 },
  red: { emoji: "🟥", color: 0xef4444 },
  orange: { emoji: "🟧", color: 0xf97316 },
  yellow: { emoji: "🟨", color: 0xfacc15 },
  green: { emoji: "🟩", color: 0x22c55e },
  blue: { emoji: "🟦", color: 0x3b82f6 },
  violet: { emoji: "🟪", color: 0x8b5cf6 },
  pink: { emoji: "💗", color: 0xec4899 },
  door: { emoji: "🚪", color: 0x8b5a2b },
  doorOpen: { emoji: "🚪", color: 0x8b5a2b },
  glass: { emoji: "🪟", color: 0x9ee7ff },
  light: { emoji: "💡", color: 0xfff4a3 },
  rainbowStairs: { emoji: "🌈", color: 0xff66cc },
  bedRed: { emoji: "🛏️", color: 0xef4444 },
  bedBlue: { emoji: "🛏️", color: 0x3b82f6 },
  bedGreen: { emoji: "🛏️", color: 0x22c55e },
  bedPink: { emoji: "🛏️", color: 0xec4899 },
  calendar: { emoji: "📅", color: 0xffffff },
  clock: { emoji: "🕒", color: 0xfacc15 },
  ladder: { emoji: "🪜", color: 0xb77935 },
  seatRed: { emoji: "🪑", color: 0xef4444 },
  seatOrange: { emoji: "🪑", color: 0xf97316 },
  seatYellow: { emoji: "🪑", color: 0xfacc15 },
  seatGreen: { emoji: "🪑", color: 0x22c55e },
  seatBlue: { emoji: "🪑", color: 0x3b82f6 },
  seatViolet: { emoji: "🪑", color: 0x8b5cf6 },
  seatPink: { emoji: "🪑", color: 0xec4899 },
  rainbowSeat: { emoji: "🌈", color: 0xffffff }
};
const BLOCK_MENU = [
  "floor", "red", "orange", "yellow", "green", "blue", "violet", "pink", "door", "glass", "light", "rainbowStairs",
  "bedRed", "bedBlue", "bedGreen", "bedPink", "calendar", "clock", "ladder",
  "seatRed", "seatOrange", "seatYellow", "seatGreen", "seatBlue", "seatViolet", "seatPink", "rainbowSeat"
];
const DEFAULT_HOTBAR = ["red", "orange", "yellow", "green", "blue", "violet", "pink", "door", "glass"];
const WORLD = 32;
const BLOCK = 1;
const PLAYER_HEIGHT = 1.7;
const PLAYER_RADIUS = 0.28;
const AUTO_STEP_HEIGHT = 0.6;
const GAME_DAY_MS = 90000;
const DAY_END_MS = GAME_DAY_MS - GAME_DAY_MS / (24 * 60);
const FIRST_WORLD_DATE = Date.UTC(2026, 0, 1);
const MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

const els = {
  menu: document.getElementById("menu"),
  game: document.getElementById("game"),
  canvas: document.getElementById("world"),
  username: document.getElementById("username"),
  gameName: document.getElementById("gameName"),
  bodyColor: document.getElementById("bodyColor"),
  headColor: document.getElementById("headColor"),
  connect: document.getElementById("connectBtn"),
  settings: document.getElementById("settingsBtn"),
  menuStatus: document.getElementById("menuStatus"),
  status: document.getElementById("connectionStatus"),
  worldName: document.getElementById("worldName"),
  mouseLock: document.getElementById("mouseLockBtn"),
  cameraToggle: document.getElementById("cameraBtn"),
  doorPrompt: document.getElementById("doorPrompt"),
  hotbar: document.getElementById("hotbar"),
  blockPicker: document.getElementById("blockPicker"),
  blockChoices: document.getElementById("blockChoices"),
  closeBlockPicker: document.getElementById("closeBlockPicker"),
  joystick: document.getElementById("joystick"),
  stick: document.querySelector("#joystick div"),
  lookPad: document.getElementById("lookPad"),
  jump: document.getElementById("jumpBtn"),
  break: document.getElementById("breakBtn"),
  place: document.getElementById("placeBtn"),
  pause: document.getElementById("pauseBtn")
};

let scene, camera, renderer, sun, ambient, hand, skyDome, avatarGroup;
let selectedType = "red";
let selectedSlot = 0;
let hotbarSlots = loadHotbarSlots();
let paused = false;
let last = performance.now();
let yaw = 0;
let pitch = -0.15;
let velocityY = 0;
let grounded = false;
let move = { x: 0, y: 0 };
let joystickMove = { x: 0, y: 0 };
let lookTouch = null;
let joyTouch = null;
let rightMouseLook = null;
let mouseLookMode = false;
let lastMousePoint = null;
let thirdPerson = false;
let player = new THREE.Vector3(0, 4, 5);
let blocks = new Map();
let blockMeshes = new Map();
let blockOrientations = new Map();
let keys = new Set();
let avatar = { bodyColor: "#2563eb", headColor: "#ffd7aa" };
let worldSaveKey = "";
let worldMetaKey = "";
let savedChanges = new Map();
let activeDoorPrompt = null;
let gameTimeMs = 0;
let currentDayIndex = 0;
let currentClockStamp = "";
let lastClockSave = 0;
let seatedAt = null;
let lastMessageAt = 0;
let sleepNeededNoticeDay = -1;
const isTouchDevice = matchMedia("(pointer: coarse)").matches || navigator.maxTouchPoints > 0;

els.username.value = localStorage.getItem("bwu-username") || `Player${Math.floor(Math.random() * 900 + 100)}`;
els.gameName.value = localStorage.getItem("bwu-game-name") || "My Block World";
els.bodyColor.value = localStorage.getItem("bwu-body-color") || "#2563eb";
els.headColor.value = localStorage.getItem("bwu-head-color") || "#ffd7aa";
document.body.classList.toggle("touch-mode", isTouchDevice);
document.body.classList.toggle("desktop-mode", !isTouchDevice);

function loadHotbarSlots() {
  try {
    const saved = JSON.parse(localStorage.getItem("bwu-hotbar") || "[]");
    if (Array.isArray(saved) && saved.length === 9 && saved.every((type) => type === null || BLOCK_MENU.includes(type))) {
      return saved;
    }
  } catch {}
  return [...DEFAULT_HOTBAR];
}

function saveHotbarSlots() {
  localStorage.setItem("bwu-hotbar", JSON.stringify(hotbarSlots));
}

function blockKey(x, y, z) {
  return `${x},${y},${z}`;
}

function parseKey(key) {
  return key.split(",").map(Number);
}

function initThree() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8bd8ff);
  scene.fog = new THREE.Fog(0x8bd8ff, 22, 70);

  camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.05, 140);
  renderer = new THREE.WebGLRenderer({ canvas: els.canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);

  ambient = new THREE.HemisphereLight(0xcff7ff, 0x2f231a, 1.05);
  sun = new THREE.DirectionalLight(0xffffff, 1.1);
  sun.position.set(20, 32, 12);
  scene.add(ambient, sun);

  addSkyDome();
  generateWorld();
  addPlayerHand();
  addAvatarModel();
  renderHotbar();
  addEventListener("resize", resize);
}

function addSkyDome() {
  const geo = new THREE.SphereGeometry(90, 24, 12);
  const mat = new THREE.MeshBasicMaterial({ color: 0x87ceeb, side: THREE.BackSide });
  skyDome = new THREE.Mesh(geo, mat);
  scene.add(skyDome);
}

function generateWorld() {
  savedChanges = loadWorldChanges();
  for (let x = -WORLD / 2; x < WORLD / 2; x++) {
    for (let z = -WORLD / 2; z < WORLD / 2; z++) {
      setBlock(x, 0, z, "floor", false);
    }
  }
  savedChanges.forEach((change) => {
    if (change.type) setBlock(change.x, change.y, change.z, change.type, false, change.orientation || 0);
    else removeBlock(change.x, change.y, change.z, false);
  });
}

function setBlock(x, y, z, type, broadcast = true, orientation = 0) {
  const key = blockKey(x, y, z);
  blocks.set(key, type);
  blockOrientations.set(key, orientation);
  const old = blockMeshes.get(key);
  if (old) scene.remove(old);
  const mesh = createBlockMesh(type);
  mesh.rotation.y += orientation;
  mesh.position.set(x + 0.5, y + meshCenterY(type), z + 0.5);
  mesh.userData.key = key;
  mesh.userData.type = type;
  mesh.userData.orientation = orientation;
  mesh.traverse?.((child) => {
    child.userData.key = key;
    child.userData.type = type;
    child.userData.orientation = orientation;
  });
  scene.add(mesh);
  blockMeshes.set(key, mesh);
  if (broadcast) rememberChange(x, y, z, type, orientation);
}

function meshCenterY(type) {
  if (type === "door" || type === "doorOpen") return 1;
  if (isBedType(type) || isSeatType(type)) return 0.3;
  if (type === "calendar" || type === "clock") return 0.38;
  if (type === "ladder") return 0.5;
  return 0.5;
}

function createBlockMesh(type) {
  const def = TYPES[type] || TYPES.red;
  if (type === "glass") {
    return new THREE.Mesh(
      new THREE.BoxGeometry(BLOCK, BLOCK, BLOCK),
      new THREE.MeshLambertMaterial({ color: def.color, transparent: true, opacity: 0.42 })
    );
  }
  if (type === "door") {
    return new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 2, 0.9),
      new THREE.MeshLambertMaterial({ color: def.color })
    );
  }
  if (type === "doorOpen") {
    const geometry = new THREE.BoxGeometry(0.18, 2, 0.9);
    geometry.translate(0.36, 0, 0);
    const mesh = new THREE.Mesh(
      geometry,
      new THREE.MeshLambertMaterial({ color: def.color })
    );
    mesh.rotation.y = Math.PI / 2;
    return mesh;
  }
  if (type === "light") {
    const group = new THREE.Group();
    const bulb = new THREE.Mesh(
      new THREE.BoxGeometry(BLOCK, BLOCK, BLOCK),
      new THREE.MeshLambertMaterial({ color: def.color, emissive: 0xfff0a0, emissiveIntensity: 0.85 })
    );
    const light = new THREE.PointLight(0xfff0a0, 1.35, 9);
    light.position.set(0, 0.35, 0);
    group.add(bulb, light);
    return group;
  }
  if (type === "rainbowStairs") {
    const group = new THREE.Group();
    const colors = [0xef4444, 0xf97316, 0xfacc15, 0x22c55e, 0x3b82f6, 0x8b5cf6, 0xec4899];
    for (let i = 0; i < 4; i++) {
      const step = new THREE.Mesh(
        new THREE.BoxGeometry(1, 0.15, 0.25),
        new THREE.MeshLambertMaterial({ color: colors[i % colors.length] })
      );
      step.position.set(0, -0.425 + i * 0.13, 0.375 - i * 0.25);
      group.add(step);
    }
    return group;
  }
  if (isBedType(type)) return createBedMesh(def.color);
  if (type === "calendar") return createCalendarMesh();
  if (type === "clock") return createClockMesh();
  if (type === "ladder") return createLadderMesh();
  if (isSeatType(type)) return createSeatMesh(type, def.color);
  return new THREE.Mesh(
    new THREE.BoxGeometry(BLOCK, BLOCK, BLOCK),
    new THREE.MeshLambertMaterial({ color: def.color })
  );
}

function isBedType(type) {
  return type?.startsWith("bed");
}

function isSeatType(type) {
  return type?.startsWith("seat") || type === "rainbowSeat";
}

function createBedMesh(color) {
  const group = new THREE.Group();
  const frame = new THREE.Mesh(
    new THREE.BoxGeometry(1, 0.18, 1),
    new THREE.MeshLambertMaterial({ color: 0x7c4a22 })
  );
  frame.position.y = -0.18;
  const blanket = new THREE.Mesh(
    new THREE.BoxGeometry(0.94, 0.18, 0.7),
    new THREE.MeshLambertMaterial({ color })
  );
  blanket.position.set(0, -0.02, -0.08);
  const pillow = new THREE.Mesh(
    new THREE.BoxGeometry(0.82, 0.14, 0.22),
    new THREE.MeshLambertMaterial({ color: 0xf8fafc })
  );
  pillow.position.set(0, 0.06, 0.34);
  group.add(frame, blanket, pillow);
  return group;
}

function createSeatMesh(type, color) {
  const group = new THREE.Group();
  const colors = type === "rainbowSeat"
    ? [0xef4444, 0xf97316, 0xfacc15, 0x22c55e, 0x3b82f6, 0x8b5cf6, 0xec4899]
    : [color, color, color, color, color, color, color];
  const seat = new THREE.Mesh(
    new THREE.BoxGeometry(0.86, 0.18, 0.86),
    new THREE.MeshLambertMaterial({ color: colors[0] })
  );
  seat.position.y = -0.04;
  const back = new THREE.Mesh(
    new THREE.BoxGeometry(0.86, 0.7, 0.14),
    new THREE.MeshLambertMaterial({ color: colors[1] })
  );
  back.position.set(0, 0.22, 0.36);
  group.add(seat, back);
  const legPositions = [[-0.3, -0.33, -0.3], [0.3, -0.33, -0.3], [-0.3, -0.33, 0.3], [0.3, -0.33, 0.3]];
  legPositions.forEach((pos, index) => {
    const leg = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.46, 0.14),
      new THREE.MeshLambertMaterial({ color: colors[index + 2] })
    );
    leg.position.set(...pos);
    group.add(leg);
  });
  return group;
}

function createCalendarMesh() {
  const group = new THREE.Group();
  const backing = new THREE.Mesh(
    new THREE.BoxGeometry(1, 0.76, 0.08),
    new THREE.MeshLambertMaterial({ color: 0x111827 })
  );
  backing.position.z = 0.04;
  const paper = new THREE.Mesh(
    new THREE.PlaneGeometry(0.94, 0.7),
    new THREE.MeshBasicMaterial({ map: createCalendarTexture(), side: THREE.DoubleSide })
  );
  paper.position.z = 0.085;
  group.add(backing, paper);
  return group;
}

function createCalendarTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#f8fafc";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#ef4444";
  ctx.fillRect(0, 0, canvas.width, 96);
  ctx.fillStyle = "#111827";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.font = "900 82px Arial";
  ctx.fillText("BLOCK WORLD DATE", canvas.width / 2, 48);
  ctx.fillStyle = "#020617";
  ctx.font = "900 118px Arial";
  ctx.fillText(formatWorldDate(), canvas.width / 2, 300);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createClockMesh() {
  const group = new THREE.Group();
  const backing = new THREE.Mesh(
    new THREE.BoxGeometry(1, 0.76, 0.08),
    new THREE.MeshLambertMaterial({ color: 0x1f2937 })
  );
  backing.position.z = 0.04;
  const face = new THREE.Mesh(
    new THREE.PlaneGeometry(0.94, 0.7),
    new THREE.MeshBasicMaterial({ map: createClockTexture(), side: THREE.DoubleSide })
  );
  face.position.z = 0.085;
  group.add(backing, face);
  return group;
}

function createClockTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#020617";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#facc15";
  ctx.fillRect(0, 0, canvas.width, 88);
  ctx.fillStyle = "#111827";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.font = "900 76px Arial";
  ctx.fillText("WORLD CLOCK", canvas.width / 2, 44);
  ctx.fillStyle = "#f8fafc";
  ctx.font = "900 142px Arial";
  ctx.fillText(formatWorldTime(), canvas.width / 2, 268);
  ctx.font = "900 54px Arial";
  ctx.fillText(isNightTime() ? "night" : "day", canvas.width / 2, 410);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createLadderMesh() {
  const group = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color: TYPES.ladder.color });
  const left = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.92, 0.08), mat);
  const right = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.92, 0.08), mat);
  left.position.set(-0.32, 0, 0.43);
  right.position.set(0.32, 0, 0.43);
  group.add(left, right);
  for (let i = 0; i < 4; i++) {
    const rung = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.07, 0.07), mat);
    rung.position.set(0, -0.32 + i * 0.22, 0.43);
    group.add(rung);
  }
  return group;
}

function removeBlock(x, y, z, broadcast = true) {
  const key = blockKey(x, y, z);
  blocks.delete(key);
  blockOrientations.delete(key);
  const mesh = blockMeshes.get(key);
  if (mesh) scene.remove(mesh);
  blockMeshes.delete(key);
  if (broadcast) rememberChange(x, y, z, null);
}

function loadWorldChanges() {
  try {
    const list = JSON.parse(localStorage.getItem(worldSaveKey) || "[]");
    return new Map(Array.isArray(list) ? list.map((change) => [blockKey(change.x, change.y, change.z), change]) : []);
  } catch {
    return new Map();
  }
}

function rememberChange(x, y, z, type, orientation = 0) {
  if (!worldSaveKey) return;
  const clean = { x, y, z, type, orientation };
  savedChanges.set(blockKey(x, y, z), clean);
  localStorage.setItem(worldSaveKey, JSON.stringify([...savedChanges.values()].slice(-1600)));
}

function loadWorldClock() {
  try {
    const meta = JSON.parse(localStorage.getItem(worldMetaKey) || "{}");
    gameTimeMs = Number.isFinite(meta.gameTimeMs) ? meta.gameTimeMs : GAME_DAY_MS * 0.24;
  } catch {
    gameTimeMs = GAME_DAY_MS * 0.24;
  }
  currentDayIndex = Math.floor(gameTimeMs / GAME_DAY_MS);
  currentClockStamp = formatWorldTime();
}

function saveWorldClock(force = false) {
  if (!worldMetaKey) return;
  const now = performance.now();
  if (!force && now - lastClockSave < 5000) return;
  lastClockSave = now;
  localStorage.setItem(worldMetaKey, JSON.stringify({ gameTimeMs }));
}

function maybeResetRequestedWorldDate(username, gameName) {
  const resetKey = "bwu-date-reset-teenu-1st-server-2026-01-10";
  if (username.trim().toLowerCase() !== "teenu" || gameName.trim() !== "1st_server" || localStorage.getItem(resetKey)) return;
  gameTimeMs = 9 * GAME_DAY_MS + GAME_DAY_MS * 0.24;
  currentDayIndex = 9;
  currentClockStamp = formatWorldTime();
  localStorage.setItem(resetKey, "done");
  saveWorldClock(true);
}

function formatWorldDate(dayIndex = currentDayIndex) {
  const date = new Date(FIRST_WORLD_DATE + dayIndex * 86400000);
  return `${date.getUTCDate()} ${MONTHS[date.getUTCMonth()]} ${date.getUTCFullYear()}`;
}

function worldDayFraction() {
  return (gameTimeMs % GAME_DAY_MS) / GAME_DAY_MS;
}

function worldHour() {
  return Math.floor(worldDayFraction() * 24);
}

function isNightTime() {
  const hour = worldHour();
  return hour >= 18 || hour < 6;
}

function smoothstep(edge0, edge1, value) {
  const t = Math.max(0, Math.min(1, (value - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

function formatWorldTime() {
  const totalMinutes = Math.floor(worldDayFraction() * 24 * 60);
  const hour = Math.floor(totalMinutes / 60) % 24;
  const minute = totalMinutes % 60;
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

function refreshDisplayBlocks() {
  [...blocks.entries()].forEach(([key, type]) => {
    if (type !== "calendar" && type !== "clock") return;
    const [x, y, z] = parseKey(key);
    const orientation = blockOrientations.get(key) || 0;
    setBlock(x, y, z, type, false, orientation);
  });
}

function applyDayNightCycle() {
  const dayFraction = worldDayFraction();
  const hour = dayFraction * 24;
  const sunAngle = ((hour - 6) / 24) * Math.PI * 2;
  const sunHeight = Math.sin(sunAngle);
  const daylight = smoothstep(-0.08, 0.28, sunHeight);
  const noonStrength = smoothstep(0.25, 0.95, sunHeight);
  const sunriseGlow = Math.max(0, 1 - Math.abs(hour - 6) / 2.2);
  const sunsetGlow = Math.max(0, 1 - Math.abs(hour - 18) / 2.2);
  const goldenHour = Math.max(sunriseGlow, sunsetGlow) * (1 - noonStrength);
  sun.position.set(Math.cos(sunAngle) * 34, Math.max(-10, sunHeight * 36), 12);
  sun.intensity = 0.06 + daylight * 0.78 + noonStrength * 0.48;
  sun.color.copy(new THREE.Color(0xff9f5a).lerp(new THREE.Color(0xffffff), noonStrength));
  ambient.intensity = 0.22 + daylight * 0.54 + noonStrength * 0.28;
  const nightSky = new THREE.Color(0x050816);
  const dawnSky = new THREE.Color(0xff8a4c);
  const daySky = new THREE.Color(0x8bd8ff);
  const sky = new THREE.Color().lerpColors(nightSky, daySky, daylight);
  sky.lerp(dawnSky, goldenHour * 0.42);
  scene.background = sky;
  scene.fog.color.copy(sky);
  scene.fog.near = 18 + daylight * 8;
  scene.fog.far = 42 + daylight * 34;
  if (skyDome) skyDome.material.color.copy(sky);
}

function advanceToMorning() {
  const nextDay = currentDayIndex + 1;
  gameTimeMs = nextDay * GAME_DAY_MS + GAME_DAY_MS * 0.24;
  currentDayIndex = Math.floor(gameTimeMs / GAME_DAY_MS);
  currentClockStamp = formatWorldTime();
  sleepNeededNoticeDay = -1;
  refreshDisplayBlocks();
  saveWorldClock(true);
}

function snappedOrientation() {
  return Math.round(yaw / (Math.PI / 2)) * (Math.PI / 2);
}

function orientationIsSideways(orientation) {
  const quarter = Math.abs(Math.round(orientation / (Math.PI / 2))) % 2;
  return quarter === 1;
}

function showStatus(message) {
  const now = performance.now();
  if (now - lastMessageAt < 500) return;
  lastMessageAt = now;
  els.status.textContent = message;
}

function placementOrientation(type) {
  const base = snappedOrientation();
  if (isBedType(type) || isSeatType(type)) return base + Math.PI;
  return base;
}

function renderHotbar() {
  els.hotbar.innerHTML = [
    ...hotbarSlots.map((type, index) => `<button class="slot${index === selectedSlot ? " active": ""}" data-slot="${index}" type="button" title="${type || "Empty"}">${type ? TYPES[type].emoji : "□"}<small>${index + 1}</small></button>`),
    `<button class="slot" data-more="true" type="button" title="More blocks">...<small>0</small></button>`
  ].join("");
}

function renderBlockPicker() {
  els.blockChoices.innerHTML = `
    <button class="block-choice" type="button" data-empty="true" title="Empty slot">
      □
      <span>Empty</span>
    </button>
  ` + BLOCK_MENU.map((type) => `
    <button class="block-choice" type="button" data-pick="${type}" title="${type}">
      ${TYPES[type].emoji}
      <span>${type.replace(/([A-Z])/g, " $1")}</span>
    </button>
  `).join("");
}

function openBlockPicker() {
  renderBlockPicker();
  els.blockPicker.classList.remove("hidden");
}

function closeBlockPicker() {
  els.blockPicker.classList.add("hidden");
}

function selectSlot(index) {
  selectedSlot = Math.max(0, Math.min(8, index));
  selectedType = hotbarSlots[selectedSlot];
  renderHotbar();
}

function startGame() {
  const username = els.username.value.trim() || "Player";
  const gameName = els.gameName.value.trim() || "My Block World";
  avatar = { bodyColor: els.bodyColor.value, headColor: els.headColor.value };
  localStorage.setItem("bwu-username", username);
  localStorage.setItem("bwu-game-name", gameName);
  localStorage.setItem("bwu-body-color", avatar.bodyColor);
  localStorage.setItem("bwu-head-color", avatar.headColor);
  const worldSlug = gameName.toLowerCase().replace(/[^a-z0-9_-]+/g, "-").slice(0, 40) || "world";
  worldSaveKey = `bwu-flat-world-${worldSlug}`;
  worldMetaKey = `bwu-flat-world-meta-${worldSlug}`;
  els.worldName.textContent = gameName;
  els.menu.classList.add("hidden");
  els.game.classList.remove("hidden");
  els.status.textContent = `Singleplayer: ${username}`;
  loadWorldClock();
  maybeResetRequestedWorldDate(username, gameName);
  if (!renderer) initThree();
  updateHandColor();
  last = performance.now();
  loop(performance.now());
}

function colorToNumber(value, fallback) {
  const clean = String(value || "").replace("#", "");
  return /^[0-9a-f]{6}$/i.test(clean) ? Number.parseInt(clean, 16) : fallback;
}

function addPlayerHand() {
  hand = new THREE.Mesh(
    new THREE.BoxGeometry(0.22, 0.55, 0.22),
    new THREE.MeshLambertMaterial({ color: colorToNumber(avatar.bodyColor, 0x2563eb) })
  );
  hand.position.set(0.45, -0.36, -0.7);
  hand.rotation.set(-0.38, 0.08, -0.12);
  camera.add(hand);
  scene.add(camera);
}

function addAvatarModel() {
  avatarGroup = new THREE.Group();
  const bodyMat = new THREE.MeshLambertMaterial({ color: colorToNumber(avatar.bodyColor, 0x2563eb) });
  const headMat = new THREE.MeshLambertMaterial({ color: colorToNumber(avatar.headColor, 0xffd7aa) });
  const darkMat = new THREE.MeshLambertMaterial({ color: 0x111827 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.82, 0.3), bodyMat);
  body.position.y = 0.82;
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.44, 0.44), headMat);
  head.position.y = 1.48;
  const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.7, 0.22), bodyMat);
  leftArm.position.set(-0.42, 0.84, 0);
  const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.7, 0.22), bodyMat);
  rightArm.position.set(0.42, 0.84, 0);
  const leftLeg = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.62, 0.24), darkMat);
  leftLeg.position.set(-0.16, 0.18, 0);
  const rightLeg = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.62, 0.24), darkMat);
  rightLeg.position.set(0.16, 0.18, 0);
  const face = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.08, 0.035), darkMat);
  face.position.set(0, 1.5, -0.24);
  avatarGroup.add(body, head, leftArm, rightArm, leftLeg, rightLeg, face);
  avatarGroup.visible = false;
  scene.add(avatarGroup);
}

function updateHandColor() {
  if (hand) hand.material.color.setHex(colorToNumber(avatar.bodyColor, 0x2563eb));
  if (avatarGroup) {
    avatarGroup.traverse((part) => {
      if (!part.isMesh) return;
      if (part.geometry?.parameters?.width === 0.55 || part.geometry?.parameters?.width === 0.18) {
        part.material.color.setHex(colorToNumber(avatar.bodyColor, 0x2563eb));
      }
    });
  }
}

function resize() {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
}

function collides(pos) {
  const minX = Math.floor(pos.x - PLAYER_RADIUS), maxX = Math.floor(pos.x + PLAYER_RADIUS);
  const minY = Math.floor(pos.y), maxY = Math.floor(pos.y + PLAYER_HEIGHT);
  const minZ = Math.floor(pos.z - PLAYER_RADIUS), maxZ = Math.floor(pos.z + PLAYER_RADIUS);
  for (let x = minX; x <= maxX; x++) for (let y = minY; y <= maxY; y++) for (let z = minZ; z <= maxZ; z++) {
    const type = blocks.get(blockKey(x, y, z));
    if (!type || type === "doorOpen") continue;
    if (type === "ladder") continue;
    if (type === "door") {
      const orientation = blockOrientations.get(blockKey(x, y, z)) || 0;
      const sideways = orientationIsSideways(orientation);
      const overlapsDoorHeight = pos.y < y + 2 && pos.y + PLAYER_HEIGHT > y;
      const closeToDoorPlane = sideways
        ? Math.abs(pos.z - (z + 0.5)) < PLAYER_RADIUS + 0.09
        : Math.abs(pos.x - (x + 0.5)) < PLAYER_RADIUS + 0.09;
      const insideDoorWidth = sideways
        ? Math.abs(pos.x - (x + 0.5)) < PLAYER_RADIUS + 0.45
        : Math.abs(pos.z - (z + 0.5)) < PLAYER_RADIUS + 0.45;
      if (overlapsDoorHeight && closeToDoorPlane && insideDoorWidth) return true;
      continue;
    }
    const height = collisionHeight(type);
    if (pos.y < y + height && pos.y + PLAYER_HEIGHT > y) return true;
    continue;
  }
  return false;
}

function collisionHeight(type) {
  if (type === "ladder") return 1;
  if (type === "rainbowStairs") return 0.5;
  if (isBedType(type) || isSeatType(type)) return 0.55;
  if (type === "calendar") return 0.8;
  return 1;
}

function wouldOverlapPlayer(x, y, z, type) {
  if (type === "door" || type === "doorOpen") {
    const overlapsY = player.y < y + 2 && player.y + PLAYER_HEIGHT > y;
    const overlapsX = Math.abs(player.x - (x + 0.5)) < PLAYER_RADIUS + 0.09;
    const overlapsZ = Math.abs(player.z - (z + 0.5)) < PLAYER_RADIUS + 0.45;
    return overlapsY && overlapsX && overlapsZ;
  }
  const height = collisionHeight(type);
  const overlapsY = player.y < y + height && player.y + PLAYER_HEIGHT > y;
  const overlapsX = Math.abs(player.x - (x + 0.5)) < PLAYER_RADIUS + 0.5;
  const overlapsZ = Math.abs(player.z - (z + 0.5)) < PLAYER_RADIUS + 0.5;
  return overlapsY && overlapsX && overlapsZ;
}

function canPlaceBlock(x, y, z, type) {
  if (blocks.has(blockKey(x, y, z))) return false;
  if ((type === "door" || type === "doorOpen") && blocks.has(blockKey(x, y + 1, z))) return false;
  return !wouldOverlapPlayer(x, y, z, type);
}

function tryAutoStep(next) {
  if (!grounded) return false;
  const stepped = next.clone();
  stepped.y += AUTO_STEP_HEIGHT;
  if (collides(stepped)) return false;
  player.copy(stepped);
  velocityY = 0;
  grounded = false;
  return true;
}

function movePlayer(next) {
  if (!collides(next)) {
    player.copy(next);
    return true;
  }
  return tryAutoStep(next);
}

function moveAxis(delta) {
  if (seatedAt) return;
  const keyboardX = (keys.has("KeyD") ? 1 : 0) - (keys.has("KeyA") ? 1 : 0);
  const keyboardY = (keys.has("KeyW") ? 1 : 0) - (keys.has("KeyS") ? 1 : 0);
  move.x = keyboardX || joystickMove.x;
  move.y = keyboardY || joystickMove.y;
  const forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
  const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  const next = player.clone();
  next.addScaledVector(forward, move.y * delta * 6);
  next.addScaledVector(right, move.x * delta * 6);
  movePlayer(next);
}

function touchingLadder(pos = player) {
  const minX = Math.floor(pos.x - PLAYER_RADIUS), maxX = Math.floor(pos.x + PLAYER_RADIUS);
  const minY = Math.floor(pos.y), maxY = Math.floor(pos.y + PLAYER_HEIGHT);
  const minZ = Math.floor(pos.z - PLAYER_RADIUS), maxZ = Math.floor(pos.z + PLAYER_RADIUS);
  for (let x = minX; x <= maxX; x++) for (let y = minY; y <= maxY; y++) for (let z = minZ; z <= maxZ; z++) {
    if (blocks.get(blockKey(x, y, z)) === "ladder") return true;
  }
  return false;
}

function physics(delta) {
  updateKeyboardLook(delta);
  if (seatedAt) {
    player.set(seatedAt.x + 0.5, seatedAt.y + 0.65, seatedAt.z + 0.5);
    velocityY = 0;
    grounded = true;
    return;
  }
  moveAxis(delta);
  if (touchingLadder()) {
    const climb = keys.has("KeyW") || keys.has("Space") || keys.has("ArrowUp");
    const descend = keys.has("KeyS") || keys.has("ArrowDown");
    velocityY = climb ? 3.6 : descend ? -2.4 : -0.6;
    grounded = true;
  } else {
    velocityY -= 18 * delta;
  }
  const nextY = player.clone();
  nextY.y += velocityY * delta;
  if (collides(nextY)) {
    if (velocityY < 0) grounded = true;
    velocityY = 0;
  } else {
    player.copy(nextY);
    grounded = false;
  }
  if (player.y < -10) respawn();
}

function updateKeyboardLook(delta) {
  if (keys.has("ArrowLeft")) yaw += delta * 2.8;
  if (keys.has("ArrowRight")) yaw -= delta * 2.8;
  if (keys.has("ArrowUp")) pitch += delta * 2.2;
  if (keys.has("ArrowDown")) pitch -= delta * 2.2;
}

function applyLookDelta(dx, dy, speed = 0.0032) {
  yaw -= dx * speed;
  pitch -= dy * speed;
  updateCamera();
}

function respawn() {
  player.set(0, 4, 5);
  velocityY = 0;
}

function updateCamera() {
  pitch = Math.max(-1.25, Math.min(1.1, pitch));
  if (avatarGroup) {
    avatarGroup.position.set(player.x, player.y, player.z);
    avatarGroup.rotation.y = yaw;
    avatarGroup.visible = thirdPerson;
  }
  if (hand) hand.visible = !thirdPerson;
  if (thirdPerson) {
    const distance = 4.2;
    const height = 2.2 - pitch * 1.35;
    const behind = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
    camera.position.set(
      player.x + behind.x * distance,
      player.y + Math.max(1.2, Math.min(3.8, height)),
      player.z + behind.z * distance
    );
    camera.lookAt(player.x, player.y + 1.05, player.z);
    return;
  }
  camera.position.set(player.x, player.y + 1.45, player.z);
  camera.rotation.order = "YXZ";
  camera.rotation.y = yaw;
  camera.rotation.x = pitch;
}

function targetBlock(point = new THREE.Vector2(0, 0)) {
  const ray = new THREE.Raycaster();
  ray.setFromCamera(point, camera);
  const hits = ray.intersectObjects([...blockMeshes.values()], true);
  const hit = hits.find((item) => item.distance < 6);
  if (!hit) return null;
  const keyed = hit.object.userData.key ? hit.object : hit.object.parent;
  if (!keyed?.userData?.key) return null;
  const [x, y, z] = parseKey(keyed.userData.key);
  const normal = hit.face.normal.clone().transformDirection(hit.object.matrixWorld);
  return { x, y, z, normal, distance: hit.distance };
}

function breakBlock() {
  const hit = targetBlock();
  if (hit && hit.y > 0) removeBlock(hit.x, hit.y, hit.z);
}

function doorPromptTarget(point) {
  const hit = targetBlock(point);
  if (!hit) return false;
  const type = blocks.get(blockKey(hit.x, hit.y, hit.z));
  if (type !== "door" && type !== "doorOpen" && !isBedType(type) && !isSeatType(type)) return false;
  if (hit.distance > 4.6) return false;
  return { ...hit, type };
}

function updateDoorPrompt() {
  activeDoorPrompt = doorPromptTarget() || null;
  if (!activeDoorPrompt) {
    els.doorPrompt.classList.add("hidden");
    return;
  }
  els.doorPrompt.querySelector("b").textContent = isTouchDevice ? "Tap" : "E";
  els.doorPrompt.querySelector("span").textContent = promptLabel(activeDoorPrompt);
  els.doorPrompt.classList.remove("hidden");
}

function promptLabel(hit) {
  if (hit.type === "door") return "Open door";
  if (hit.type === "doorOpen") return "Close door";
  if (isBedType(hit.type)) return isNightTime() ? "Sleep" : "Sleep at night";
  if (isSeatType(hit.type)) {
    return seatedAt && seatedAt.x === hit.x && seatedAt.y === hit.y && seatedAt.z === hit.z ? "Stand up" : "Sit";
  }
  return "Use";
}

function interactPromptDoor() {
  const hit = activeDoorPrompt || doorPromptTarget();
  if (!hit) return false;
  const type = blocks.get(blockKey(hit.x, hit.y, hit.z));
  if (type === "door" || type === "doorOpen") {
    const orientation = blockOrientations.get(blockKey(hit.x, hit.y, hit.z)) || 0;
    setBlock(hit.x, hit.y, hit.z, type === "door" ? "doorOpen" : "door", true, orientation);
  } else if (isBedType(type)) {
    if (!isNightTime()) {
      showStatus("You can only sleep at night.");
      return true;
    }
    advanceToMorning();
  } else if (isSeatType(type)) {
    if (seatedAt && seatedAt.x === hit.x && seatedAt.y === hit.y && seatedAt.z === hit.z) {
      seatedAt = null;
    } else {
      seatedAt = { x: hit.x, y: hit.y, z: hit.z };
      player.set(hit.x + 0.5, hit.y + 0.65, hit.z + 0.5);
      velocityY = 0;
      grounded = true;
    }
  } else {
    return false;
  }
  updateDoorPrompt();
  return true;
}

function placeBlock() {
  if (!selectedType) {
    showStatus("Empty slot selected");
    return;
  }
  const hit = targetBlock();
  if (!hit) return;
  const x = hit.x + Math.round(hit.normal.x);
  const y = hit.y + Math.round(hit.normal.y);
  const z = hit.z + Math.round(hit.normal.z);
  const orientation = selectedType === "door" || selectedType === "rainbowStairs" || isBedType(selectedType) || isSeatType(selectedType) || selectedType === "calendar" || selectedType === "clock" || selectedType === "ladder" ? placementOrientation(selectedType) : 0;
  if (canPlaceBlock(x, y, z, selectedType)) setBlock(x, y, z, selectedType, true, orientation);
}

function loop(time) {
  if (paused) return;
  const delta = Math.min(0.04, (time - last) / 1000);
  last = time;
  const dayEndTime = currentDayIndex * GAME_DAY_MS + DAY_END_MS;
  if (gameTimeMs < dayEndTime) {
    gameTimeMs = Math.min(gameTimeMs + delta * 1000, dayEndTime);
  } else if (sleepNeededNoticeDay !== currentDayIndex) {
    sleepNeededNoticeDay = currentDayIndex;
    showStatus("Sleep in a bed to start a new day.");
    saveWorldClock(true);
  }
  const dayIndex = currentDayIndex;
  const clockStamp = formatWorldTime();
  if (dayIndex !== currentDayIndex) {
    currentDayIndex = dayIndex;
    currentClockStamp = clockStamp;
    refreshDisplayBlocks();
    saveWorldClock(true);
  } else if (clockStamp !== currentClockStamp) {
    currentClockStamp = clockStamp;
    refreshDisplayBlocks();
  } else {
    saveWorldClock();
  }
  applyDayNightCycle();
  physics(delta);
  updateCamera();
  updateDoorPrompt();
  renderer.render(scene, camera);
  requestAnimationFrame(loop);
}

function jump() {
  if (seatedAt) {
    seatedAt = null;
    return;
  }
  if (grounded) {
    velocityY = 7.2;
    grounded = false;
  }
}

function setJoystick(clientX, clientY) {
  const rect = els.joystick.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const dx = clientX - cx;
  const dy = clientY - cy;
  const max = rect.width * 0.34;
  const len = Math.min(max, Math.hypot(dx, dy));
  const angle = Math.atan2(dy, dx);
  const x = Math.cos(angle) * len;
  const y = Math.sin(angle) * len;
  els.stick.style.transform = `translate(${x}px, ${y}px)`;
  joystickMove.x = x / max;
  joystickMove.y = -y / max;
}

els.connect.addEventListener("click", startGame);
els.settings.addEventListener("click", () => {
  els.menuStatus.textContent = isTouchDevice
    ? "Mobile/tablet: left joystick moves, right side swipes camera, Jump/Break/Place buttons build. Prompts appear for doors, beds, and seats."
    : "PC: press Lock Mouse or right-click the game, then move mouse to look while walking/jumping. Esc unlocks.";
});
els.pause.addEventListener("click", () => {
  paused = !paused;
  els.pause.textContent = paused ? "▶" : "II";
  if (!paused) {
    last = performance.now();
    requestAnimationFrame(loop);
  }
});
els.jump.addEventListener("pointerdown", jump);
els.break.addEventListener("pointerdown", breakBlock);
els.place.addEventListener("pointerdown", placeBlock);
els.doorPrompt.addEventListener("pointerdown", (event) => {
  event.preventDefault();
  interactPromptDoor();
});
els.hotbar.addEventListener("click", (event) => {
  const more = event.target.closest("[data-more]");
  if (more) {
    openBlockPicker();
    return;
  }
  const btn = event.target.closest("[data-slot]");
  if (!btn) return;
  selectSlot(Number(btn.dataset.slot));
  closeBlockPicker();
});
els.blockChoices.addEventListener("click", (event) => {
  const empty = event.target.closest("[data-empty]");
  if (empty) {
    hotbarSlots[selectedSlot] = null;
    selectedType = null;
    saveHotbarSlots();
    renderHotbar();
    closeBlockPicker();
    return;
  }
  const btn = event.target.closest("[data-pick]");
  if (!btn) return;
  hotbarSlots[selectedSlot] = btn.dataset.pick;
  selectedType = btn.dataset.pick;
  saveHotbarSlots();
  renderHotbar();
  closeBlockPicker();
});
els.closeBlockPicker.addEventListener("click", closeBlockPicker);
els.joystick.addEventListener("pointerdown", (event) => {
  joyTouch = event.pointerId;
  els.joystick.setPointerCapture(event.pointerId);
  setJoystick(event.clientX, event.clientY);
});
els.joystick.addEventListener("pointermove", (event) => {
  if (event.pointerId === joyTouch) setJoystick(event.clientX, event.clientY);
});
function clearJoy(event) {
  if (event.pointerId !== joyTouch) return;
  joyTouch = null;
  move.x = 0;
  move.y = 0;
  joystickMove.x = 0;
  joystickMove.y = 0;
  els.stick.style.transform = "translate(0, 0)";
}
els.joystick.addEventListener("pointerup", clearJoy);
els.joystick.addEventListener("pointercancel", clearJoy);
els.lookPad.addEventListener("pointerdown", (event) => {
  lookTouch = { id: event.pointerId, x: event.clientX, y: event.clientY };
  els.lookPad.setPointerCapture(event.pointerId);
});
els.lookPad.addEventListener("pointermove", (event) => {
  if (!lookTouch || event.pointerId !== lookTouch.id) return;
  yaw -= (event.clientX - lookTouch.x) * 0.006;
  pitch -= (event.clientY - lookTouch.y) * 0.006;
  lookTouch.x = event.clientX;
  lookTouch.y = event.clientY;
});
els.lookPad.addEventListener("pointerup", () => { lookTouch = null; });
els.lookPad.addEventListener("pointercancel", () => { lookTouch = null; });

function lockMouseLook() {
  if (els.game.classList.contains("hidden")) return;
  setMouseLookMode(true);
  els.canvas.focus({ preventScroll: true });
  if (document.pointerLockElement !== els.canvas) {
    const request = els.canvas.requestPointerLock?.({ unadjustedMovement: true });
    if (request?.catch) request.catch(() => els.canvas.requestPointerLock?.());
  }
}

function setMouseLookMode(active) {
  mouseLookMode = active;
  lastMousePoint = null;
  document.body.classList.toggle("mouse-look-mode", active);
  if (!els.game.classList.contains("hidden")) {
    const locked = document.pointerLockElement === els.canvas;
    els.status.textContent = active || locked ? "Mouse look ON" : "Singleplayer";
    els.mouseLock.textContent = active || locked ? "Esc unlocks" : "Lock Mouse";
  }
}

function toggleCameraMode() {
  thirdPerson = !thirdPerson;
  els.cameraToggle.textContent = thirdPerson ? "3rd" : "1st";
  els.status.textContent = thirdPerson ? "Third person camera" : "First person camera";
}

els.mouseLock.addEventListener("click", lockMouseLook);
els.cameraToggle.addEventListener("click", toggleCameraMode);

els.canvas.addEventListener("contextmenu", (event) => {
  event.preventDefault();
  lockMouseLook();
});

els.canvas.addEventListener("mousedown", (event) => {
  if (event.button !== 2) return;
  event.preventDefault();
  rightMouseLook = { x: event.clientX, y: event.clientY };
  lockMouseLook();
});

document.addEventListener("mouseup", (event) => {
  if (event.button === 2) rightMouseLook = null;
});

document.addEventListener("pointerlockchange", () => {
  if (!els.game.classList.contains("hidden")) {
    const locked = document.pointerLockElement === els.canvas;
    setMouseLookMode(Boolean(locked || rightMouseLook));
  }
});

document.addEventListener("pointerlockerror", () => {
  if (!els.game.classList.contains("hidden")) {
    els.status.textContent = "Click Lock Mouse to allow camera control.";
  }
});

function handleMouseLook(event) {
  if (paused) return;
  const locked = document.pointerLockElement === els.canvas;
  if (locked || mouseLookMode) {
    event.preventDefault();
    let dx = event.movementX || 0;
    let dy = event.movementY || 0;
    if (!dx && !dy && event.clientX != null) {
      if (lastMousePoint) {
        dx = event.clientX - lastMousePoint.x;
        dy = event.clientY - lastMousePoint.y;
      }
      lastMousePoint = { x: event.clientX, y: event.clientY };
    }
    applyLookDelta(dx, dy);
    return;
  }
  if (rightMouseLook) {
    event.preventDefault();
    applyLookDelta(event.clientX - rightMouseLook.x, event.clientY - rightMouseLook.y, 0.0042);
    rightMouseLook.x = event.clientX;
    rightMouseLook.y = event.clientY;
  }
}

document.addEventListener("mousemove", handleMouseLook, true);
document.addEventListener("pointerrawupdate", handleMouseLook, true);
els.canvas.addEventListener("mousemove", handleMouseLook, true);

document.addEventListener("keydown", (event) => {
  keys.add(event.code);
  if (["Space", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.code)) {
    event.preventDefault();
  }
  if (event.code === "Escape") {
    setMouseLookMode(false);
    if (document.pointerLockElement === els.canvas) document.exitPointerLock?.();
  }
  if (seatedAt && ["KeyW", "KeyA", "KeyS", "KeyD", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.code)) {
    seatedAt = null;
  }
  if (event.code === "Space") {
    jump();
  }
  if (event.code === "KeyF") breakBlock();
  if (event.code === "KeyC") toggleCameraMode();
  if (event.code === "KeyE") {
    if (!interactPromptDoor()) placeBlock();
  }
  if (event.key === "0") {
    openBlockPicker();
    return;
  }
  const slot = Number(event.key);
  if (slot >= 1 && slot <= 9) {
    selectSlot(slot - 1);
  }
}, true);

document.addEventListener("keyup", (event) => {
  keys.delete(event.code);
}, true);

els.canvas.addEventListener("click", (event) => {
  if (event.button !== 0) return;
  els.canvas.focus({ preventScroll: true });
});

if (location.search.includes("debugBlockworld=1")) {
  window.BlockWorldUltraDebug = {
    state: () => ({
      x: player.x,
      y: player.y,
      z: player.z,
      yaw,
      pitch,
      selectedType,
      selectedSlot,
      hotbarSlots: [...hotbarSlots],
      pickerOpen: !els.blockPicker.classList.contains("hidden"),
      mouseLookMode: Boolean(mouseLookMode),
      thirdPerson,
      pointerLocked: document.pointerLockElement === els.canvas,
      doorPrompt: activeDoorPrompt,
      orientations: Object.fromEntries(blockOrientations)
    }),
    forceLook: (dx, dy) => applyLookDelta(dx, dy),
    forceKey: (code, active) => active ? keys.add(code) : keys.delete(code),
    setPlayer: (x, y, z) => {
      player.set(x, y, z);
      velocityY = 0;
      grounded = true;
    },
    setBlock: (x, y, z, type, orientation = 0) => setBlock(x, y, z, type, false, orientation),
    canPlaceBlock,
    openPicker: openBlockPicker,
    pickBlock: (type) => {
      if (type === null || type === "empty") {
        hotbarSlots[selectedSlot] = null;
        selectedType = null;
        saveHotbarSlots();
        renderHotbar();
        return true;
      }
      if (!BLOCK_MENU.includes(type)) return false;
      hotbarSlots[selectedSlot] = type;
      selectedType = type;
      saveHotbarSlots();
      renderHotbar();
      return true;
    }
  };
}
